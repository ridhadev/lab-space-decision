# Decision Space | Retail Geospatial Intelligence Platform

> **Geospatial decision-support system and portfolio optimization engine for Bedashing Beauty Lounge's 23-store network across the United Arab Emirates.**

---

## 1. Business Context & Strategic Purpose

**Bedashing Beauty Lounge** is one of the UAE's premier beauty and wellness operators, running **23 locations** across Abu Dhabi, Dubai, and the Northern Emirates. As the brand expands within rapidly growing master-planned communities, corporate leadership faces key capital allocation and spatial dilemmas:

1. **Portfolio Defense vs. Rightsizing**: Which existing branches represent high-margin "crown jewels" requiring priority CapEx protection, versus underperforming locations suffering from severe local competitor saturation?
2. **Sister-Branch Cannibalization**: Rapid urban expansion has placed several branches within competing trade areas (< 4.0 km separation), dividing foot traffic rather than capturing incremental revenue.
3. **White-Space Expansion Prioritization**: Where among the UAE's high-growth residential corridors (e.g., Dubai Hills, Saadiyat Cultural District) should new capital be deployed to capture unmet luxury demand without cannibalizing existing stores?

**Decision Space** delivers a unified, deterministic, and AI-grounded intelligence platform to answer these questions for executive management, investment committees, and the Board of Directors.

---

## 2. Core Capabilities & Features

- **Interactive Geospatial Network Map**:
  Leaflet-powered map utilizing CartoDB Dark Matter basemaps. Displays all 23 Bedashing lounges, 10 candidate growth zones, 3 km primary catchment radii, dynamic sister-proximity lines, a **Thermal Competition Density & Saturation Heatmap** (Blue-to-Red thermal gradient mapping local salon saturation from low-density moats to hyper-saturated retail corridors), a **Coverage Gap & "White Space" Analysis Layer** (cyan/teal opportunity auras and directional reach vectors highlighting unserved high-affluence trade pockets), and an **Expandable/Collapsible Map Layers Panel** with one-click hide/show controls and automated **Center of Gravity Camera Navigation** that centers and scales map viewports directly on the weighted geographic centroid of any selected emirate (`UAE`, `AD`, `DXB`, `SHJ`, `FUJ`, `RAK`).
- **Market Saturation Metric in Summary Badges & Tables**:
  4-tier competitive saturation classification (`Monopolistic Moat 1–4`, `Balanced 5–9`, `Saturated 10–17`, `Hyper-Saturated 18+`). Integrated into the Executive Summary portfolio banner strip, interactive filter chips, and sortable table columns across all 23 branches and 10 candidate growth zones, with deep-dive audit tooltips and modal breakdowns.
- **Deterministic Multi-Factor Scoring Engine**:
  Auditable, mathematically transparent evaluation:
  - **Existing Branches**: Classified into \`PROTECT\` (≥ 85), \`HOLD\` (70–84), or \`SHRINK\` (< 70) based on reputation, catchment affluence, sister distance, and competitor saturation.
  - **Candidate Zones**: Ranked into \`GROW\` (≥ 80), \`WATCH\` (65–79), or \`SKIP\` (< 65) based on unmet demand, affluence, retail anchors, and safety buffers.
- **Automated Cannibalization Detection**:
  Continuous monitoring of sister-store proximity using spherical Haversine calculations ($R=6,371\\text{ km}$). Lounges with < 4.0 km separation are flagged with revenue-at-risk dilution alerts.
- **Dynamic What-If Sensitivity Modeling**:
  Interactive slider controls enabling executives to adjust weighting matrices in real time, with instant client-side recalculation.
- **Grounded AI Advisor & Board Memorandum**:
  Dual-path executive briefing engine powered by Google Gemini 3.8 Flash with a zero-downtime deterministic fallback. Generates formal Board of Directors strategic memoranda and natural-language branch rationales rendered through a high-contrast, fully formatted Markdown presentation pipeline (`react-markdown` + `remark-gfm`). Features per-location session isolation with browser `localStorage` caching (`/src/services/aiStorage.ts`) and active real-time processing indicators with pulsing radar states and shimmering skeleton rows.
- **Built-In Architecture & Methodology Documentation**:
  Interactive technical reference with complete data provenance and mathematical proofs served directly at \`/docs\` and embedded within the app.

---

## 3. Quick Start: Local Installation & Execution

Follow these steps to run Decision Space locally after downloading or cloning from GitHub.

### Prerequisites
- **Node.js**: Version \`20.x\` or higher (\`18.x\` LTS also supported)
- **npm**: Version \`9.x\` or higher (or \`pnpm\` / \`bun\`)
- **Git**

---

### Step 1: Clone the Repository
\`\`\`bash
git clone https://github.com/your-org/decision-space.git
cd decision-space
\`\`\`

---

### Step 2: Install Dependencies
Install the required frontend and backend packages:
\`\`\`bash
npm install
\`\`\`

---

### Step 3: Configure Environment Variables & API Keys

Copy the sample environment file:
\`\`\`bash
cp .env.example .env
\`\`\`

Open \`.env\` in your text editor:
\`\`\`env
# Google Gemini API Key (Optional)
# Required for natural-language AI Advisor chat & Board Memo LLM generation.
# If omitted, the platform uses its built-in deterministic briefing generator.
GEMINI_API_KEY=

# Google Drive Sync (Optional)
GOOGLE_DRIVE_FOLDER_ID=1fjPVxav6Zp-I9U0sPh1uHVEgqJwXt-cA
GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY=

# CARTO Basemap API Key (Optional)
# CARTO appends a watermark flag on raster tiles without an authenticated key.
# A default key is pre-configured in the codebase; you can override it here.
CARTO_API_KEY=
VITE_CARTO_API_KEY=
\`\`\`

#### 🔑 API Key Reference Guide:

| Integration | API Key Required? | Where to Set | Notes |
| :--- | :---: | :--- | :--- |
| **CARTO / Basemap Tiles** | ⚡ **Optional** (Pre-set) | \`.env\` (\`VITE_CARTO_API_KEY\`) | Removes the CARTO "API key required" watermark flag from Dark Matter tiles. The app includes a default authenticated key out of the box. |
| **Deterministic Scoring** | ❌ **No** | *None* | All Haversine distance, cannibalization, and scoring formulas execute 100% locally in-memory. |
| **Google Gemini (AI Advisor)** | ⚡ **Optional** | \`.env\` (\`GEMINI_API_KEY\`) | Obtain a free key from [Google AI Studio](https://aistudio.google.com). If not provided, the platform automatically activates its built-in deterministic briefing generator without crashing. |
| **Google Drive Sync** | ⚡ **Optional** | \`.env\` (\`GOOGLE_DRIVE_...\`) | Optional. The app loads verified local snapshots from \`/src/data/specs.ts\` by default. |

---

### Step 4: Run the Development Server
Launch the unified full-stack development environment (Express API + Vite Dev Server):
\`\`\`bash
npm run dev
\`\`\`

Open your browser to:
👉 **\`http://localhost:3000\`**

- The main interactive geospatial dashboard will open immediately.
- To access the technical architecture documentation, click the **"Architecture Docs"** tab or visit **\`http://localhost:3000/docs\`**.

---

### Step 5: Production Build & Deployment (Optional)
To test the production build locally:
\`\`\`bash
# 1. Compile the React client and bundle the Express server into dist/
npm run build

# 2. Run the bundled production server
npm start
\`\`\`
The server will bind to \`http://localhost:3000\`.

---

## 4. Repository & Architecture Structure

\`\`\`
decision-space/
├── AGENTS.md                  # Dedicated AI Agent instructions & synchronization rules
├── README.md                  # Project overview and quick start guide (this file)
├── .env.example               # Template for environment variables
├── package.json               # Node.js project manifest & script commands
├── server.ts                  # Express backend: Gemini AI proxy, Drive sync, and static docs
├── docs/                      # Static technical & strategic documentation
│   └── index.html             # Standalone searchable documentation web page
├── public/                    # Static assets served directly
│   └── docs/index.html        # Production mirror of the documentation web page
└── src/                       # Client-side React 19 application
    ├── App.tsx                # Main layout, tab navigation, and modal controllers
    ├── types.ts               # Central TypeScript interfaces (Branch, Candidate, Evaluation)
    ├── data/
    │   ├── branches.ts        # Verified dataset of 23 Bedashing UAE locations
    │   ├── candidates.ts      # 10 prospective rollout zones with demographics
    │   └── specs.ts           # Technical specifications from client brief
    ├── services/
    │   ├── scoringEngine.ts   # Pure deterministic math: Haversine, scores, classifications
    │   └── firebaseAuth.ts    # Authentication and user session handler
    └── components/
        ├── GeospatialMap.tsx  # Leaflet map with 3km catchments & custom markers
        ├── BranchTable.tsx    # Interactive sorting and filtering table of branches
        ├── CandidateTable.tsx # Expansion ranking and ROI prioritization table
        ├── AiAdvisor.tsx      # Grounded strategic advisory dialogue
        ├── BoardMemoModal.tsx # Formal C-Suite & Board memo generator
        └── Header.tsx         # Navigation bar with quick link to documentation
\`\`\`

---

## 5. Data Provenance & Grounding Notice

- **Collected Data**: Store names, physical street addresses, geocodes (lat/lng), and Google star ratings/review counts are collected from public records and geocoded via Google Maps.
- **Calculated Math**: Distance matrices between all branches and candidate areas are derived using the spherical Haversine formula ($R=6,371\\text{ km}$).
- **Modeled Proxies**: Local competitor density counts within 3 km, catchment affluence indices, chair counts, and visitor volumes are modeled benchmarks (Bedashing internal POS records remain confidential).
- For complete audit details, view the **Provenance Matrix** in the documentation at \`/docs\`.

---

## 6. Documentation Maintenance Protocol

This project includes a dedicated governance agent protocol documented in **\`AGENTS.md\`**. Any AI agent modifying this codebase is mandated to:
1. Verify and update both **\`docs/index.html\`** and **\`README.md\`** whenever formulas, thresholds, data records, or server configurations are modified.
2. Keep all mathematical formulas, scoring cutoffs (\`PROTECT\` ≥ 85, \`HOLD\` 70–84, \`SHRINK\` < 70), and buffer distances (4.0km sister buffer, 3.0km competitor radius) in 100% lockstep across code and documentation.
